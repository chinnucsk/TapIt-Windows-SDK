TapIt Windows Phone SDK
v1.0.0

Quick Install:
1) Copy the TapIt-WP8.dll file to your project folder.
2) Right click on the references folder in the project.
3) Click the add reference option.
4) Browse for TapIt-WP8.dll and click ok.
5) Project need to add following Device Capabilities in order to use WP8 SDK.
   * ID_CAP_IDENTITY_DEVICE
   * ID_CAP_LOCATION

Complete implementation instructions can be found at:
https://github.com/tapit/TapIt-Windows-SDK
